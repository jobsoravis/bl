-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 04, 2022 at 06:55 PM
-- Server version: 5.7.23
-- PHP Version: 7.1.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `uat_bl`
--

-- --------------------------------------------------------

--
-- Table structure for table `page`
--

CREATE TABLE `page` (
  `page_id` varchar(32) NOT NULL,
  `page_group_id` varchar(33) NOT NULL,
  `page_name` varchar(100) NOT NULL,
  `is_active` char(1) NOT NULL,
  `is_page` char(1) NOT NULL,
  `redirect` varchar(100) NOT NULL,
  `check_view` char(1) NOT NULL,
  `check_create_update` char(1) NOT NULL,
  `check_delete` char(1) NOT NULL,
  `check_approve` char(1) NOT NULL,
  `description` varchar(200) NOT NULL,
  `user_create` varchar(32) NOT NULL,
  `user_update` varchar(32) NOT NULL,
  `time_create` timestamp NULL DEFAULT NULL,
  `time_update` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `page`
--

INSERT INTO `page` (`page_id`, `page_group_id`, `page_name`, `is_active`, `is_page`, `redirect`, `check_view`, `check_create_update`, `check_delete`, `check_approve`, `description`, `user_create`, `user_update`, `time_create`, `time_update`) VALUES
('P01', 'GP01', 'Dashboard', '1', '1', '1', '1', '1', '1', '0', 'Dashboard', '', '', NULL, NULL),
('P02', 'GP02', 'Payroll', '1', '1', '1', '1', '1', '1', '0', 'รายการเงินเดือน', '', '', NULL, NULL),
('P03', 'GP03', 'Employee Profile', '1', '0', '1', '1', '1', '1', '0', 'Employee Profile', '', '', NULL, NULL),
('P04', 'GP03', 'Employee Type', '1', '0', '1', '1', '1', '1', '0', 'Employee Type', '', '', NULL, NULL),
('P05', 'GP03', 'Payment Type', '1', '1', '1', '1', '1', '1', '1', 'รายการ รายได้/รายการหัก', '', '', NULL, NULL),
('P06', 'GP03', 'Payment Group', '1', '0', '0', '0', '0', '0', '0', 'Payment Group', '', '', NULL, NULL),
('P07', 'GP03', 'Payment Term', '1', '0', '0', '0', '0', '0', '0', 'Payment Term', '', '', NULL, NULL),
('P08', 'GP03', 'Department', '1', '1', '1', '1', '1', '1', '0', 'Department', '', '', NULL, NULL),
('P09', 'GP03', 'Position', '1', '1', '1', '1', '1', '1', '0', 'Position', '', '', NULL, NULL),
('P10', 'GP03', 'Holiday', '1', '1', '1', '1', '1', '1', '0', 'Holiday', '', '', NULL, NULL),
('P11', 'GP04', 'Report Working', '1', '1', '1', '1', '1', '1', '0', 'รายงาน ข้อมูลการทำงาน', '', '', NULL, NULL),
('P12', 'GP04', 'Report Payment', '1', '1', '1', '1', '1', '1', '0', 'รายงาน รายการจ่ายเงินเดือน', '', '', NULL, NULL),
('P13', 'GP04', 'Report Wages', '1', '1', '1', '1', '1', '1', '0', 'รายงาน เงินเดือน/ค่าจ้างสะสม', '', '', NULL, NULL),
('P14', 'GP04', 'Report Salary', '1', '1', '1', '1', '1', '1', '0', 'รายงาน เงินเดือนแยกตามแผนก', '', '', NULL, NULL),
('P15', 'GP04', 'Report Income_Expend', '1', '1', '1', '1', '1', '1', '0', 'รายงาน รายได้เพิ่มเติม/รายการหัก', '', '', NULL, NULL),
('P16', 'GP04', 'Report SSI', '1', '1', '1', '1', '1', '1', '0', 'รายงาน เงินประกันสังคม', '', '', NULL, NULL),
('P17', 'GP04', 'Payments Slips', '1', '1', '1', '1', '1', '1', '0', 'สลิปเงินเดือน แยกตามรายการจ่าย', '', '', NULL, NULL),
('P18', 'GP04', 'Individual Slips', '1', '1', '1', '1', '1', '1', '0', 'สลิปเงินเดือน แยกตามบุคคล', '', '', NULL, NULL),
('P19', 'GP04', 'Payment Statistics', '1', '1', '1', '1', '1', '1', '0', 'Payment Statistics', '', '', NULL, NULL),
('P20', 'GP04', 'Employee Statistics', '1', '1', '1', '1', '1', '1', '0', 'Employee Statistics', '', '', NULL, NULL),
('P21', 'GP04', 'Department Statistics', '1', '1', '1', '1', '1', '1', '0', 'Department Statistics', '', '', NULL, NULL),
('P22', 'GP04', 'Payment Chart', '1', '1', '1', '1', '1', '1', '0', 'Payment Chart', '', '', NULL, NULL),
('P23', 'GP04', 'Employee yearly statistics', '1', '1', '1', '1', '1', '1', '0', 'Employee yearly statistics', '', '', NULL, NULL),
('P24', 'GP05', 'System User', '1', '1', '1', '1', '1', '1', '0', 'System User', '', '', NULL, NULL),
('P25', 'GP05', 'User Management', '1', '1', '1', '1', '1', '1', '0', 'User Management', '', '', NULL, NULL),
('P26', 'GP05', 'Role Management', '1', '1', '1', '1', '1', '1', '0', 'Role Management', '', '', NULL, NULL),
('P27', 'GP05', 'Page menu', '1', '1', '1', '1', '1', '1', '0', 'Page menu', '', '', NULL, NULL),
('P28', 'GP06', 'Migrate Data', '1', '1', '1', '1', '1', '1', '0', 'Migrate Data', '', '', NULL, NULL),
('P29', 'GP07', 'Actual', '1', '1', '1', '1', '1', '1', '0', 'วันทำงานจริง', '', '', NULL, NULL),
('P30', 'GP07', 'Salary', '1', '1', '1', '1', '1', '1', '0', 'เงินเดือน', '', '', NULL, NULL),
('P31', 'GP07', 'SSI', '1', '1', '1', '1', '1', '1', '0', 'ประกันสังคม', '', '', NULL, NULL),
('P32', 'GP07', 'Tax', '1', '1', '1', '1', '1', '1', '0', 'ภาษี', '', '', NULL, NULL),
('P33', 'GP03', 'Salary Config', '1', '0', '0', '1', '1', '0', '0', 'ปรับเงินเดือน', ' ', ' ', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `page_group`
--

CREATE TABLE `page_group` (
  `page_group_id` varchar(32) NOT NULL,
  `group_name` varchar(64) NOT NULL,
  `is_active` char(1) NOT NULL,
  `description` varchar(200) NOT NULL,
  `user_create` varchar(32) NOT NULL,
  `user_update` varchar(32) NOT NULL,
  `time_create` timestamp NULL DEFAULT NULL,
  `time_update` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `page_group`
--

INSERT INTO `page_group` (`page_group_id`, `group_name`, `is_active`, `description`, `user_create`, `user_update`, `time_create`, `time_update`) VALUES
('GP01', 'Dashboard', '1', 'Dashboard', '', '', NULL, NULL),
('GP02', 'Payroll', '1', 'รายการเงินเดือน', '', '', NULL, NULL),
('GP03', 'Master Data', '1', 'Master', '', '', NULL, NULL),
('GP04', 'Report', '1', 'รายงาน', '', '', NULL, NULL),
('GP05', 'Authority', '1', 'ระบบรักษาความปลอดภัย', '', '', NULL, NULL),
('GP06', 'Migrate Data', '1', 'Migrate', '', '', NULL, NULL),
('GP07', 'Function', '1', 'Function', '', '', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `permission`
--

CREATE TABLE `permission` (
  `permission_id` bigint(20) NOT NULL,
  `sys_role_id` varchar(32) NOT NULL,
  `page_id` varchar(33) DEFAULT NULL,
  `page_name` varchar(64) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `page_group_active` char(1) DEFAULT NULL,
  `page_active` char(1) DEFAULT NULL,
  `view` char(1) DEFAULT NULL,
  `create_update` char(1) DEFAULT NULL,
  `delete_role` char(1) DEFAULT NULL,
  `approve` char(1) DEFAULT NULL,
  `user_create` varchar(32) DEFAULT NULL,
  `user_update` varchar(32) DEFAULT NULL,
  `time_create` timestamp NULL DEFAULT NULL,
  `time_update` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `permission`
--

INSERT INTO `permission` (`permission_id`, `sys_role_id`, `page_id`, `page_name`, `description`, `page_group_active`, `page_active`, `view`, `create_update`, `delete_role`, `approve`, `user_create`, `user_update`, `time_create`, `time_update`) VALUES
(1, '2', 'P01', 'Dashboard', NULL, '1', '0', '0', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-09-04 16:45:26'),
(2, '2', 'P02', 'รายการจ่ายเงินเดือน', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-09-04 16:45:27'),
(3, '2', 'P03', 'พนักงาน', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-09-04 16:45:28'),
(4, '2', 'P04', 'แผนก', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-09-04 16:45:28'),
(5, '2', 'P05', 'ตำแหน่ง', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-09-04 16:45:28'),
(6, '2', 'P06', 'ประเภทพนักงาน', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-09-04 16:45:28'),
(7, '2', 'P07', 'รายการ รายได้/รายการหัก', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-09-04 16:45:28'),
(8, '2', 'P08', 'ประเภทพนักงาน', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-09-04 16:45:28'),
(9, '2', 'P09', 'เงินเดือน', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-09-04 16:45:28'),
(10, '2', 'P10', 'ประวัติเงินเดือน', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-09-04 16:45:28'),
(11, '2', 'P11', 'Report working', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-08-07 16:16:45'),
(12, '2', 'P12', 'Page menu', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-08-07 16:16:45'),
(13, '2', 'P13', 'User', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-08-07 16:16:45'),
(14, '2', 'P14', 'Role', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-08-07 16:16:45'),
(16, '3', 'P01', 'Dashboard', NULL, '1', '1', '1', '1', '1', '0', 'thanet.s', 'thanet.s', '2022-07-19 03:36:54', '2022-09-03 14:55:11'),
(17, '3', 'P02', 'รายการจ่ายเงินเดือน', NULL, '1', '1', '1', '1', '1', '0', 'thanet.s', 'thanet.s', '2022-07-19 03:36:54', '2022-09-03 14:55:15'),
(18, '3', 'P03', 'พนักงาน', NULL, '1', '1', '1', '1', '1', '0', 'thanet.s', 'thanet.s', '2022-07-19 03:36:54', '2022-09-03 14:57:53'),
(19, '3', 'P04', 'แผนก', NULL, '1', '1', '1', '1', '1', '0', 'thanet.s', 'thanet.s', '2022-07-19 03:36:54', '2022-09-03 14:57:56'),
(20, '3', 'P05', 'ตำแหน่ง', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:36:54', '2022-09-03 15:05:54'),
(21, '3', 'P06', 'ประเภทพนักงาน', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-07-19 03:36:54', '2022-07-19 03:36:55'),
(22, '3', 'P07', 'รายการ รายได้/รายการหัก', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-07-19 03:36:54', '2022-07-19 03:36:55'),
(23, '3', 'P08', 'ประเภทพนักงาน', NULL, '1', '1', '1', '1', '1', '0', 'thanet.s', 'thanet.s', '2022-07-19 03:36:54', '2022-09-03 15:06:08'),
(24, '3', 'P09', 'เงินเดือน', NULL, '1', '1', '1', '1', '1', '0', 'thanet.s', 'thanet.s', '2022-07-19 03:36:54', '2022-09-03 15:06:11'),
(25, '3', 'P10', 'ประวัติเงินเดือน', NULL, '1', '1', '1', '1', '1', '0', 'thanet.s', 'thanet.s', '2022-07-19 03:36:54', '2022-09-03 15:06:15'),
(26, '3', 'P11', 'Report working', NULL, '1', '1', '1', '1', '1', '0', 'thanet.s', 'thanet.s', '2022-07-19 03:36:54', '2022-09-03 15:06:21'),
(27, '3', 'P12', 'Page menu', NULL, '1', '1', '1', '1', '1', '0', 'thanet.s', 'thanet.s', '2022-07-19 03:36:54', '2022-09-03 15:06:22'),
(28, '3', 'P13', 'User', NULL, '1', '0', '1', '1', '1', '0', 'thanet.s', 'thanet.s', '2022-07-19 03:36:54', '2022-09-03 15:06:24'),
(29, '3', 'P14', 'Role', NULL, '1', '1', '1', '1', '1', '0', 'thanet.s', 'thanet.s', '2022-07-19 03:36:54', '2022-09-03 15:06:28'),
(31, '4', 'P01', 'Dashboard', NULL, '1', '0', '0', '0', '0', '0', 'weerawat.p', 'weerawat.p', '2022-07-19 05:18:44', '2022-07-19 05:18:44'),
(32, '4', 'P02', 'รายการจ่ายเงินเดือน', NULL, '1', '0', '0', '0', '0', '0', 'weerawat.p', 'weerawat.p', '2022-07-19 05:18:44', '2022-07-19 05:18:44'),
(33, '4', 'P03', 'พนักงาน', NULL, '1', '0', '0', '0', '0', '0', 'weerawat.p', 'weerawat.p', '2022-07-19 05:18:44', '2022-07-19 05:18:44'),
(34, '4', 'P04', 'แผนก', NULL, '1', '0', '0', '0', '0', '0', 'weerawat.p', 'weerawat.p', '2022-07-19 05:18:44', '2022-07-19 05:18:44'),
(35, '4', 'P05', 'ตำแหน่ง', NULL, '1', '0', '0', '0', '0', '0', 'weerawat.p', 'weerawat.p', '2022-07-19 05:18:44', '2022-07-19 05:18:44'),
(36, '4', 'P06', 'ประเภทพนักงาน', NULL, '1', '0', '0', '0', '0', '0', 'weerawat.p', 'weerawat.p', '2022-07-19 05:18:44', '2022-07-19 05:18:44'),
(37, '4', 'P07', 'รายการ รายได้/รายการหัก', NULL, '1', '0', '0', '0', '0', '0', 'weerawat.p', 'weerawat.p', '2022-07-19 05:18:44', '2022-07-19 05:18:44'),
(38, '4', 'P08', 'ประเภทพนักงาน', NULL, '1', '0', '0', '0', '0', '0', 'weerawat.p', 'weerawat.p', '2022-07-19 05:18:44', '2022-07-19 05:18:44'),
(39, '4', 'P09', 'เงินเดือน', NULL, '1', '0', '0', '0', '0', '0', 'weerawat.p', 'weerawat.p', '2022-07-19 05:18:44', '2022-07-19 05:18:44'),
(40, '4', 'P10', 'ประวัติเงินเดือน', NULL, '1', '0', '0', '0', '0', '0', 'weerawat.p', 'weerawat.p', '2022-07-19 05:18:44', '2022-07-19 05:18:44'),
(41, '4', 'P11', 'Report working', NULL, '1', '0', '0', '0', '0', '0', 'weerawat.p', 'weerawat.p', '2022-07-19 05:18:44', '2022-07-19 05:18:44'),
(42, '4', 'P12', 'Page menu', NULL, '1', '0', '0', '0', '0', '0', 'weerawat.p', 'weerawat.p', '2022-07-19 05:18:44', '2022-07-19 05:18:44'),
(43, '4', 'P13', 'User', NULL, '1', '0', '0', '0', '0', '0', 'weerawat.p', 'weerawat.p', '2022-07-19 05:18:44', '2022-07-19 05:18:44'),
(44, '4', 'P14', 'Role', NULL, '1', '0', '0', '0', '0', '0', 'weerawat.p', 'weerawat.p', '2022-07-19 05:18:44', '2022-07-19 05:18:44'),
(46, '5', 'P01', 'Dashboard', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-07-19 06:04:44', '2022-07-19 06:04:44'),
(47, '5', 'P02', 'รายการจ่ายเงินเดือน', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-07-19 06:04:44', '2022-07-19 06:04:44'),
(48, '5', 'P03', 'พนักงาน', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-07-19 06:04:44', '2022-07-19 06:04:44'),
(49, '5', 'P04', 'แผนก', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-07-19 06:04:44', '2022-07-19 06:04:44'),
(50, '5', 'P05', 'ตำแหน่ง', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-07-19 06:04:44', '2022-07-19 06:04:44'),
(51, '5', 'P06', 'ประเภทพนักงาน', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-07-19 06:04:44', '2022-07-19 06:04:44'),
(52, '5', 'P07', 'รายการ รายได้/รายการหัก', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-07-19 06:04:44', '2022-07-19 06:04:44'),
(53, '5', 'P08', 'ประเภทพนักงาน', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-07-19 06:04:44', '2022-07-19 06:04:44'),
(54, '5', 'P09', 'เงินเดือน', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-07-19 06:04:44', '2022-07-19 06:04:44'),
(55, '5', 'P10', 'ประวัติเงินเดือน', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-07-19 06:04:44', '2022-07-19 06:04:44'),
(56, '5', 'P11', 'Report working', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-07-19 06:04:44', '2022-07-19 06:04:44'),
(57, '5', 'P12', 'Page menu', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-07-19 06:04:44', '2022-07-19 06:04:44'),
(58, '5', 'P13', 'User', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-07-19 06:04:44', '2022-07-19 06:04:44'),
(59, '5', 'P14', 'Role', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-07-19 06:04:44', '2022-07-19 06:04:44'),
(61, '6', 'P01', 'Dashboard', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-01 04:11:32', '2022-08-01 04:11:32'),
(62, '6', 'P02', 'รายการจ่ายเงินเดือน', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-01 04:11:32', '2022-08-01 06:25:45'),
(63, '6', 'P03', 'พนักงาน', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-01 04:11:32', '2022-08-01 04:11:32'),
(64, '6', 'P04', 'แผนก', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-01 04:11:32', '2022-08-01 04:11:32'),
(65, '6', 'P05', 'ตำแหน่ง', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-01 04:11:32', '2022-08-01 04:11:32'),
(66, '6', 'P06', 'ประเภทพนักงาน', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-01 04:11:32', '2022-08-01 04:11:32'),
(67, '6', 'P07', 'รายการ รายได้/รายการหัก', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-01 04:11:32', '2022-08-01 04:11:32'),
(68, '6', 'P08', 'ประเภทพนักงาน', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-01 04:11:32', '2022-08-01 04:11:32'),
(69, '6', 'P09', 'เงินเดือน', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-01 04:11:32', '2022-08-01 04:11:32'),
(70, '6', 'P10', 'ประวัติเงินเดือน', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-01 04:11:32', '2022-08-01 04:11:32'),
(71, '6', 'P11', 'Report working', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-01 04:11:32', '2022-08-01 04:11:32'),
(72, '6', 'P12', 'Page menu', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-01 04:11:32', '2022-08-01 04:11:32'),
(73, '6', 'P13', 'User', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-01 04:11:32', '2022-08-01 04:11:32'),
(74, '6', 'P14', 'Role', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-01 04:11:32', '2022-08-01 04:11:32'),
(76, '7', 'P01', 'Dashboard', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-01 04:12:23', '2022-08-01 04:12:23'),
(77, '7', 'P02', 'รายการจ่ายเงินเดือน', NULL, '0', '1', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-01 04:12:23', '2022-08-01 07:16:40'),
(78, '7', 'P03', 'พนักงาน', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-01 04:12:23', '2022-08-01 06:31:35'),
(79, '7', 'P04', 'แผนก', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-01 04:12:23', '2022-08-01 06:31:35'),
(80, '7', 'P05', 'ตำแหน่ง', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-01 04:12:23', '2022-08-01 06:31:35'),
(81, '7', 'P06', 'ประเภทพนักงาน', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-01 04:12:23', '2022-08-01 06:31:35'),
(82, '7', 'P07', 'รายการ รายได้/รายการหัก', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-01 04:12:23', '2022-08-01 06:31:35'),
(83, '7', 'P08', 'ประเภทพนักงาน', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-01 04:12:23', '2022-08-01 06:31:35'),
(84, '7', 'P09', 'เงินเดือน', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-01 04:12:23', '2022-08-01 06:31:35'),
(85, '7', 'P10', 'ประวัติเงินเดือน', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-01 04:12:23', '2022-08-01 06:31:35'),
(86, '7', 'P11', 'Report working', NULL, '1', '1', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-01 04:12:23', '2022-08-01 06:31:10'),
(87, '7', 'P12', 'Page menu', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-01 04:12:23', '2022-08-01 04:12:23'),
(88, '7', 'P13', 'User', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-01 04:12:23', '2022-08-01 04:12:23'),
(89, '7', 'P14', 'Role', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-01 04:12:23', '2022-08-01 04:12:23'),
(91, '8', 'P01', 'Dashboard', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-02 03:23:53', '2022-08-02 03:23:53'),
(92, '8', 'P02', 'รายการจ่ายเงินเดือน', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-02 03:23:53', '2022-08-02 03:27:36'),
(93, '8', 'P03', 'พนักงาน', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-02 03:23:53', '2022-08-02 03:28:51'),
(94, '8', 'P04', 'แผนก', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-02 03:23:53', '2022-08-02 03:23:53'),
(95, '8', 'P05', 'ตำแหน่ง', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-02 03:23:53', '2022-08-02 03:23:53'),
(96, '8', 'P06', 'ประเภทพนักงาน', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-02 03:23:53', '2022-08-02 03:23:53'),
(97, '8', 'P07', 'รายการ รายได้/รายการหัก', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-02 03:23:53', '2022-08-02 03:23:53'),
(98, '8', 'P08', 'ประเภทพนักงาน', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-02 03:23:53', '2022-08-02 03:23:53'),
(99, '8', 'P09', 'เงินเดือน', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-02 03:23:53', '2022-08-02 03:23:53'),
(100, '8', 'P10', 'ประวัติเงินเดือน', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-02 03:23:53', '2022-08-02 03:23:53'),
(101, '8', 'P11', 'Report working', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-02 03:23:53', '2022-08-02 03:29:25'),
(102, '8', 'P12', 'Page menu', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-02 03:23:53', '2022-08-02 03:23:53'),
(103, '8', 'P13', 'User', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-02 03:23:53', '2022-08-02 03:23:53'),
(104, '8', 'P14', 'Role', NULL, '1', '0', '0', '0', '0', '0', 'thanet.s', 'thanet.s', '2022-08-02 03:23:53', '2022-08-02 03:23:53'),
(106, '2', 'P01', 'Dashboard', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-09-04 16:45:26'),
(107, '2', 'P02', 'Payroll', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-09-04 16:45:27'),
(108, '2', 'P03', 'Employee Profile', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-09-04 16:45:28'),
(109, '2', 'P04', 'Employee Type', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-09-04 16:45:28'),
(110, '2', 'P05', 'Payment Type', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-09-04 16:45:28'),
(111, '2', 'P06', 'Payment Group', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-09-04 16:45:28'),
(112, '2', 'P07', 'Payment Term', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-09-04 16:45:28'),
(113, '2', 'P08', 'Department', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-09-04 16:45:28'),
(114, '2', 'P09', 'Position', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-09-04 16:45:28'),
(115, '2', 'P10', 'Holiday', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-09-04 16:45:28'),
(116, '2', 'P11', 'Report Working', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-08-07 16:16:45'),
(117, '2', 'P12', 'Report Payment', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-08-07 16:16:45'),
(118, '2', 'P13', 'Report Wages', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-08-07 16:16:45'),
(119, '2', 'P14', 'Report Salary', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-08-07 16:16:45'),
(120, '2', 'P15', 'Report Income/Expend', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-08-07 16:16:45'),
(121, '2', 'P16', 'Report SSI', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-08-07 16:16:45'),
(122, '2', 'P17', 'Payments Slips', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-08-07 16:16:45'),
(123, '2', 'P18', 'Individual Slips', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-08-07 16:16:45'),
(124, '2', 'P19', 'Payment Statistics', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-08-07 16:16:45'),
(125, '2', 'P20', 'Employee Statistics', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-08-07 16:16:45'),
(126, '2', 'P21', 'Department Statistics', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-08-07 16:16:45'),
(127, '2', 'P22', 'Payment Chart', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-08-07 16:16:45'),
(128, '2', 'P23', 'Employee yearly statistics', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-08-07 16:16:45'),
(129, '2', 'P24', 'System User', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-08-07 16:16:45'),
(130, '2', 'P25', 'User Management', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-08-07 16:16:45'),
(131, '2', 'P26', 'Role Management', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-08-07 16:16:45'),
(132, '2', 'P27', 'Page menu', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-08-07 16:16:45'),
(133, '2', 'P28', 'Migrate Data', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-08-07 16:16:45'),
(134, '2', 'P29', 'Actual', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-08-07 16:16:45'),
(135, '2', 'P30', 'Salary', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-08-07 16:16:45'),
(136, '2', 'P31', 'SSI', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-08-07 16:16:45'),
(137, '2', 'P32', 'Tax', NULL, '1', '0', '0', '0', '0', '1', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-09-04 16:41:41'),
(169, '10', 'P01', 'Dashboard', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-26 08:01:20', '2022-08-08 02:00:45'),
(170, '10', 'P02', 'Payroll', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-26 08:01:20', '2022-08-08 02:00:45'),
(171, '10', 'P03', 'Employee Profile', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-26 08:01:20', '2022-08-08 02:00:45'),
(172, '10', 'P04', 'Employee Type', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-26 08:01:20', '2022-08-08 02:00:45'),
(173, '10', 'P05', 'Payment Type', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-26 08:01:20', '2022-08-08 02:00:45'),
(174, '10', 'P06', 'Payment Group', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-26 08:01:20', '2022-08-08 02:00:45'),
(175, '10', 'P07', 'Payment Term', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-26 08:01:20', '2022-08-08 02:00:45'),
(176, '10', 'P08', 'Department', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-26 08:01:20', '2022-08-08 02:00:45'),
(177, '10', 'P09', 'Position', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-26 08:01:20', '2022-08-08 02:00:45'),
(178, '10', 'P10', 'Holiday', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-26 08:01:20', '2022-08-08 02:00:45'),
(179, '10', 'P11', 'Report Working', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'Thanet.s', '2022-07-26 08:01:20', '2022-08-08 03:01:30'),
(180, '10', 'P12', 'Report Payment', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'Thanet.s', '2022-07-26 08:01:20', '2022-08-08 03:01:30'),
(181, '10', 'P13', 'Report Wages', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'Thanet.s', '2022-07-26 08:01:20', '2022-08-08 03:01:30'),
(182, '10', 'P14', 'Report Salary', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'Thanet.s', '2022-07-26 08:01:20', '2022-08-08 03:01:30'),
(183, '10', 'P15', 'Report Income_Expend', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'Thanet.s', '2022-07-26 08:01:20', '2022-08-08 03:01:30'),
(184, '10', 'P16', 'Report SSI', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'Thanet.s', '2022-07-26 08:01:20', '2022-08-08 03:01:30'),
(185, '10', 'P17', 'Payments Slips', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'Thanet.s', '2022-07-26 08:01:20', '2022-08-08 03:01:30'),
(186, '10', 'P18', 'Individual Slips', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'Thanet.s', '2022-07-26 08:01:20', '2022-08-08 03:01:30'),
(187, '10', 'P19', 'Payment Statistics', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'Thanet.s', '2022-07-26 08:01:20', '2022-08-08 03:01:30'),
(188, '10', 'P20', 'Employee Statistics', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'Thanet.s', '2022-07-26 08:01:20', '2022-08-08 03:01:30'),
(189, '10', 'P21', 'Department Statistics', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'Thanet.s', '2022-07-26 08:01:20', '2022-08-08 03:01:30'),
(190, '10', 'P22', 'Payment Chart', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'Thanet.s', '2022-07-26 08:01:20', '2022-08-08 03:01:30'),
(191, '10', 'P23', 'Employee yearly statistics', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'Thanet.s', '2022-07-26 08:01:20', '2022-08-08 03:01:30'),
(192, '10', 'P24', 'System User', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-26 08:01:20', '2022-08-08 02:00:45'),
(193, '10', 'P25', 'User Management', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-26 08:01:20', '2022-08-08 02:00:45'),
(194, '10', 'P26', 'Role Management', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-26 08:01:20', '2022-08-08 02:00:45'),
(195, '10', 'P27', 'Page menu', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-26 08:01:20', '2022-08-08 02:00:45'),
(196, '10', 'P28', 'Migrate Data', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-26 08:01:20', '2022-08-08 02:00:45'),
(197, '10', 'P29', 'Actual', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-26 08:01:20', '2022-08-08 02:00:45'),
(198, '10', 'P30', 'Salary', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-26 08:01:20', '2022-08-08 02:00:45'),
(199, '10', 'P31', 'SSI', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-26 08:01:20', '2022-08-08 02:00:45'),
(200, '10', 'P32', 'Tax', NULL, '1', '1', '1', '1', '1', '1', 'thanet.s', 'thanet.s', '2022-07-26 08:01:20', '2022-08-08 02:00:45'),
(232, '10', 'P33', 'Salary Config', NULL, '1', '1', '1', '1', '0', '0', 'sirung', 'sirung', '2022-08-24 06:08:19', '2022-08-24 06:08:22');

-- --------------------------------------------------------

--
-- Table structure for table `sys_role`
--

CREATE TABLE `sys_role` (
  `sys_role_id` bigint(20) NOT NULL,
  `name` varchar(64) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  `administrator` char(1) NOT NULL,
  `user_create` varchar(32) NOT NULL,
  `user_update` varchar(32) NOT NULL,
  `time_create` timestamp NULL DEFAULT NULL,
  `time_update` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sys_role`
--

INSERT INTO `sys_role` (`sys_role_id`, `name`, `description`, `administrator`, `user_create`, `user_update`, `time_create`, `time_update`) VALUES
(2, 'HR071', '', '0', 'thanet.s', 'thanet.s', '2022-07-19 03:21:29', '2022-09-04 16:47:24'),
(3, 'admin', 'administrator', '0', 'thanet.s', 'thanet.s', '2022-07-19 03:36:54', '2022-09-04 15:50:42'),
(4, 'IT', 'IT', '0', 'weerawat.p', 'weerawat.p', '2022-07-19 05:18:44', '2022-07-19 05:18:46'),
(6, 'fd', 'dd', '0', 'thanet.s', 'thanet.s', '2022-08-01 04:11:32', '2022-08-01 04:11:32'),
(10, 'superadmin', 'Super Administrator', '0', 'thanet.s', 'thanet.s', '2022-07-26 08:01:20', '2022-07-26 08:45:27');

-- --------------------------------------------------------

--
-- Table structure for table `sys_user`
--

CREATE TABLE `sys_user` (
  `sys_user_id` varchar(32) NOT NULL,
  `sys_role_id` varchar(32) DEFAULT NULL,
  `user_id` varchar(32) DEFAULT NULL,
  `name_th` varchar(200) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `phone` varchar(10) DEFAULT NULL,
  `is_active` char(1) NOT NULL,
  `password` varchar(32) NOT NULL,
  `user_create` varchar(32) NOT NULL,
  `user_update` varchar(32) NOT NULL,
  `time_create` timestamp NULL DEFAULT NULL,
  `time_update` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sys_user`
--

INSERT INTO `sys_user` (`sys_user_id`, `sys_role_id`, `user_id`, `name_th`, `email`, `phone`, `is_active`, `password`, `user_create`, `user_update`, `time_create`, `time_update`) VALUES
('dffg', 'admin', NULL, 'ฉันสินี แต้ไฟสิฐ', '', '0897752509', '1', 'B95495D2B655E0CD832244427261B76A', 'thanet.s', 'thanet.s', '2022-07-19 02:11:24', '2022-09-03 15:07:48'),
('sirung', 'superadmin', 'sirung.t', 'Sirung Thaisa', 'sirung.t@cubesofttech.com', '0969517754', '1', '75B13E8047D95EFC3EEA8A98AEBEB8EF', 'Thanet.s', 'Thanet.s', '2022-08-09 08:22:54', '2022-08-09 08:22:54'),
('thanet.s', 'superadmin', 'Thanet.s', 'Thanet Sutphan', 'Thanet.s@cubesofttech.com', '', '1', '1BAFCFB8D2AB7E4019F141C171C7ACFE', 'thanet.s', 'thanet.s', '2022-07-26 08:46:39', '2022-07-26 08:46:39'),
('w', NULL, 'admin', 'แอดมิน', 'jobsakul@gmail.com', '1234567899', '1', '3E677DC3B6110B77928EFC9CF7B65F88', 'thanet.s', 'Thanet.s', '2022-07-21 10:36:42', '2022-08-25 03:31:01');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `page`
--
ALTER TABLE `page`
  ADD PRIMARY KEY (`page_id`);

--
-- Indexes for table `page_group`
--
ALTER TABLE `page_group`
  ADD PRIMARY KEY (`page_group_id`);

--
-- Indexes for table `permission`
--
ALTER TABLE `permission`
  ADD PRIMARY KEY (`permission_id`);

--
-- Indexes for table `sys_role`
--
ALTER TABLE `sys_role`
  ADD PRIMARY KEY (`sys_role_id`);

--
-- Indexes for table `sys_user`
--
ALTER TABLE `sys_user`
  ADD PRIMARY KEY (`sys_user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `permission`
--
ALTER TABLE `permission`
  MODIFY `permission_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=233;

--
-- AUTO_INCREMENT for table `sys_role`
--
ALTER TABLE `sys_role`
  MODIFY `sys_role_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
